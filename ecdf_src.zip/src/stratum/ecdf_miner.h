#pragma once
#include <stdint.h>
#include <math.h>

// ── Compile-time knobs ────────────────────────────────────────────────────────
#ifndef ECDF_MIN_GAPS
# define ECDF_MIN_GAPS 1600
#endif
#ifndef ECDF_DEFAULT_CONF
# define ECDF_DEFAULT_CONF 0.10f
#endif
#ifndef ECDF_CALIB_BUDGET
# define ECDF_CALIB_BUDGET 500000000000000u
#endif

// ecdf_window(): clamp range for the confidence value `p` passed in.
// p <= 0 is snapped up to ECDF_CONF_FLOOR; p >= 1 is snapped down to ECDF_CONF_CEIL.
#ifndef ECDF_CONF_FLOOR
# define ECDF_CONF_FLOOR 0.01f
#endif
#ifndef ECDF_CONF_CEIL
# define ECDF_CONF_CEIL 0.999f
#endif

// rng_unit() floor: avoids log(1-u) blowing up to -inf when u rounds to 1.0.
#ifndef ECDF_RNG_EPSILON
# define ECDF_RNG_EPSILON 1e-7f
#endif

// ── Bootstrap knobs (used before s.fitted becomes true) ───────────────────────
// When the ASIC hasn't returned enough gaps yet, ecdf_scan_window_asic falls
// back to a diff-scaled window instead of the learned mean_gap/cv model.
#ifndef ECDF_BOOTSTRAP_DIFF_FALLBACK
# define ECDF_BOOTSTRAP_DIFF_FALLBACK 65536u   // used when asic.get_asic_diff() == 0
#endif
#ifndef ECDF_BOOTSTRAP_LEAP_B_MULT
# define ECDF_BOOTSTRAP_LEAP_B_MULT 2u         // leap_B = leap_A * this, pre-fit
#endif

// ── ASIC listen-window knobs (ecdf_scan_window_asic) ──────────────────────────
#ifndef ECDF_ASIC_MAX_TIMEOUT_MS
# define ECDF_ASIC_MAX_TIMEOUT_MS 8000u   // hard cap on total listen budget
#endif
#ifndef ECDF_ASIC_PER_LISTEN_MS
# define ECDF_ASIC_PER_LISTEN_MS 200u     // per-call slice passed to listen_asic_rsp
#endif

// ── Dual-curve leap knobs ─────────────────────────────────────────────────────
// Curve A  Exp(1):      leap_A = -mean_gap * ln(1-u)             mean = mean_gap
// Curve B  Gamma(2,1):  leap_B = -mean_gap*(ln(1-u1)+ln(1-u2))  mean = 2*mean_gap
//
// Blend weight alpha = clamp(cv, 0, 1):
//   cv -> 0  (regular gaps)  => trust Curve A (Exp)
//   cv -> 1  (bursty gaps)   => lean Curve B  (Gamma)
//
// alpha_override >= 0 => manual blend; < 0 => auto (use cv)
#ifndef ECDF_LEAP_SEED
# define ECDF_LEAP_SEED 0xDEADBEEFu
#endif

// ── State ─────────────────────────────────────────────────────────────────────
struct ecdf_state_t {
    float    mean_gap;   // online mean of inter-hit gaps
    float    m2;         // Welford M2 accumulator
    float    cv;         // coefficient of variation (stddev / mean)
    uint32_t n_gaps;     // number of gaps observed
    uint32_t anchor;     // last confirmed nonce (or calibration position)
    bool     fitted;     // true once n_gaps >= ECDF_MIN_GAPS

    // xorshift32 RNG for dual-curve leap (no stdlib rand() dependency)
    uint32_t rng;
};

struct ecdf_result_t {
    bool     hit;
    uint32_t nonce;
    uint32_t hashes;
    float    conf_actual;
};

// ── Core ECDF ─────────────────────────────────────────────────────────────────
void     ecdf_reset    (ecdf_state_t &s);
bool     ecdf_add_gap  (ecdf_state_t &s, uint32_t gap);
uint32_t ecdf_window   (const ecdf_state_t &s, float p);
float    ecdf_conf     (const ecdf_state_t &s, uint32_t budget);
float    ecdf_marginal (const ecdf_state_t &s, uint32_t budget);

// ── Dual-curve leap ───────────────────────────────────────────────────────────
// Advances s.anchor by an interpolated Exp(1)/Gamma(2,1) leap.
// Returns the leap offset applied.
// alpha_override < 0 => auto-blend from cv.
uint32_t ecdf_leap(ecdf_state_t &s, float alpha_override = -1.0f);

// ── Calibration / scan / mine ─────────────────────────────────────────────────
uint32_t      ecdf_calibrate  (ecdf_state_t &s, uint32_t budget,
                               bool (*is_valid_fn)(uint32_t));
ecdf_result_t ecdf_scan_window(ecdf_state_t &s, float conf,
                               bool (*is_valid_fn)(uint32_t));
uint32_t      ecdf_mine       (ecdf_state_t &s, float conf,
                               uint32_t target_hits, uint32_t max_hashes,
                               bool (*is_valid_fn)(uint32_t),
                               void (*on_hit_fn)(uint32_t));

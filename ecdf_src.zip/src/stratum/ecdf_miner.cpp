#include "ecdf_miner.h"

// ── Internal xorshift32 ───────────────────────────────────────────────────────
static inline uint32_t xorshift32(uint32_t &state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}
static inline float rng_unit(uint32_t &state) {
    uint32_t v = xorshift32(state);
    return (float)(v >> 1) / (float)(1u << 31);
}

// ── ecdf_reset ────────────────────────────────────────────────────────────────
void ecdf_reset(ecdf_state_t &s) {
    s.mean_gap = 0.0f;
    s.m2       = 0.0f;
    s.cv       = 0.0f;
    s.n_gaps   = 0;
    s.anchor   = 0;
    s.fitted   = false;
    s.rng      = ECDF_LEAP_SEED;
}

// ── ecdf_add_gap ──────────────────────────────────────────────────────────────
bool ecdf_add_gap(ecdf_state_t &s, uint32_t gap) {
    s.n_gaps++;
    float delta  = (float)gap - s.mean_gap;
    s.mean_gap  += delta / (float)s.n_gaps;
    float delta2 = (float)gap - s.mean_gap;
    s.m2        += delta * delta2;

    if (s.n_gaps >= 2) {
        float variance = s.m2 / (float)(s.n_gaps - 1);
        float stddev   = (variance > 0.0f) ? sqrtf(variance) : 0.0f;
        s.cv = (s.mean_gap > 0.0f) ? (stddev / s.mean_gap) : 0.0f;
    }
    if (s.n_gaps >= ECDF_MIN_GAPS)
        s.fitted = true;
    return s.fitted;
}

// ── ecdf_window ───────────────────────────────────────────────────────────────
uint32_t ecdf_window(const ecdf_state_t &s, float p) {
    if (!s.fitted || s.mean_gap <= 0.0f) return 1u;
    if (p <= 0.0f) p = ECDF_CONF_FLOOR;
    if (p >= 1.0f) p = ECDF_CONF_CEIL;

    float mg    = s.mean_gap;
    float alpha = s.cv;
    if (alpha > 1.0f) alpha = 1.0f;
    if (alpha < 0.0f) alpha = 0.0f;

    // Curve A quantile: Exp(mean_gap) inverse CDF
    float wA = -mg * logf(1.0f - p);

    // Curve B quantile: Erlang(2, mean_gap/2) inverse CDF via Newton-Raphson.
    // F(x) = 1 - e^(-x/theta) * (1 + x/theta);  f(x) = (x/theta^2) * e^(-x/theta)
    float theta = mg * 0.5f;
    float wB    = wA;   // initial guess
    for (int it = 0; it < 5; it++) {
        float e = expf(-wB / theta);
        float F = 1.0f - e * (1.0f + wB / theta);
        float f = (wB / (theta * theta)) * e;
        if (f < 1e-9f) break;
        wB -= (F - p) / f;
        if (wB < 0.0f) wB = 0.0f;
    }

    // Blend by the same alpha (cv) the leap uses, so the window genuinely
    // reflects the observed spread/range, not just the raw mean.
    float w = (1.0f - alpha) * wA + alpha * wB;
    return (w < 1.0f) ? 1u : (uint32_t)(w + 0.5f);
}

// ── ecdf_conf ─────────────────────────────────────────────────────────────────
float ecdf_conf(const ecdf_state_t &s, uint32_t budget) {
    if (!s.fitted || s.mean_gap <= 0.0f) return 0.0f;
    return 1.0f - expf(-(float)budget / s.mean_gap);
}

// ── ecdf_marginal ─────────────────────────────────────────────────────────────
float ecdf_marginal(const ecdf_state_t &s, uint32_t budget) {
    if (!s.fitted || s.mean_gap <= 0.0f) return 0.0f;
    return expf(-(float)budget / s.mean_gap) / s.mean_gap;
}

// ── ecdf_leap ─────────────────────────────────────────────────────────────────
//
// Dual-curve interpolated anchor leap:
//
//   Curve A  Exp(1):      leap_A = -mean_gap * ln(1-u)
//   Curve B  Gamma(2,1):  leap_B = -mean_gap * (ln(1-u1) + ln(1-u2))
//
//   alpha = cv  (auto) or caller override in [0,1]
//     alpha = 0 -> pure Curve A  (regular gap regime, cv near 0)
//     alpha = 1 -> pure Curve B  (bursty gap regime, cv near 1+)
//
//   leap = round( (1-alpha)*leap_A + alpha*leap_B )
//
// Anchor is advanced by leap and the offset is returned.
// ─────────────────────────────────────────────────────────────────────────────
uint32_t ecdf_leap(ecdf_state_t &s, float alpha_override) {
    float mg = (s.fitted && s.mean_gap > 0.0f) ? s.mean_gap : 1.0f;

    float u1 = rng_unit(s.rng);
    float u2 = rng_unit(s.rng);
    if (u1 < ECDF_RNG_EPSILON) u1 = ECDF_RNG_EPSILON;
    if (u2 < ECDF_RNG_EPSILON) u2 = ECDF_RNG_EPSILON;

    // Curve A — Exp(1) scaled by mean_gap
    float leap_A = -mg * logf(1.0f - u1);
    // Curve B — Gamma(2,1) = Erlang(2,1), scaled by mean_gap
    float leap_B = -mg * (logf(1.0f - u1) + logf(1.0f - u2));

    float alpha = (alpha_override >= 0.0f) ? alpha_override : s.cv;
    if (alpha > 1.0f) alpha = 1.0f;
    if (alpha < 0.0f) alpha = 0.0f;

    float leap_f  = (1.0f - alpha) * leap_A + alpha * leap_B;
    uint32_t leap = (leap_f < 1.0f) ? 1u : (uint32_t)(leap_f + 0.5f);

    s.anchor += leap;
    return leap;
}

// ── ecdf_calibrate ────────────────────────────────────────────────────────────
uint32_t ecdf_calibrate(ecdf_state_t &s, uint32_t budget,
                        bool (*is_valid_fn)(uint32_t nonce)) {
    uint32_t hits      = 0;
    uint32_t prev      = 0;
    bool     have_prev = false;

    for (uint32_t n = 0; n < budget; n++) {
        if (is_valid_fn(n)) {
            hits++;
            if (have_prev)
                ecdf_add_gap(s, n - prev);
            prev      = n;
            have_prev = true;
            s.anchor  = n;
            if (s.fitted) break;
        }
    }
    return hits;
}

// ── ecdf_scan_window ──────────────────────────────────────────────────────────
// When fitted: leap to predicted zone, then scan conf-width window there.
// When unfitted: linear scan from anchor.
// ─────────────────────────────────────────────────────────────────────────────
ecdf_result_t ecdf_scan_window(ecdf_state_t &s, float conf,
                               bool (*is_valid_fn)(uint32_t nonce)) {
    ecdf_result_t r = {false, 0, 0, conf};
    if (conf <= 0.0f) conf = ECDF_DEFAULT_CONF;
    r.conf_actual = conf;

    uint32_t start, w;
    if (s.fitted) {
        ecdf_leap(s);        // advances s.anchor to predicted zone
        start = s.anchor;
        w     = ecdf_window(s, conf);
    } else {
        w     = ecdf_window(s, conf);
        start = s.anchor + 1;
    }

    uint32_t end = start + w;
    if (end < start) end = 0xFFFFFFFFu;  // wrap guard

    for (uint32_t n = start; n <= end; n++) {
        if (is_valid_fn(n)) {
            r.hit    = true;
            r.nonce  = n;
            r.hashes = n - (start - 1);
            ecdf_add_gap(s, n - s.anchor);
            s.anchor = n;
            return r;
        }
    }
    r.hashes = w;
    s.anchor = end;
    return r;
}

// ── ecdf_mine ────────────────────────────────────────────────────────────────
uint32_t ecdf_mine(ecdf_state_t &s, float conf,
                   uint32_t target_hits, uint32_t max_hashes,
                   bool (*is_valid_fn)(uint32_t nonce),
                   void (*on_hit_fn)(uint32_t nonce)) {
    if (conf <= 0.0f) conf = ECDF_DEFAULT_CONF;
    uint32_t total = 0, hits = 0;
    while (hits < target_hits && total < max_hashes) {
        ecdf_result_t r = ecdf_scan_window(s, conf, is_valid_fn);
        total += r.hashes;
        if (r.hit) { hits++; if (on_hit_fn) on_hit_fn(r.nonce); }
    }
    return total;
}

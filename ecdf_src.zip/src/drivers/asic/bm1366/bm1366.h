#ifndef BM1366_H_
#define BM1366_H_
#include "drivers/asic/bm_hal.h"

#define BM1366_CORE_COUNT       112
#define BM1366_SMALL_CORE_COUNT 894

class BM1366: public BMxxx{
private:
    uint32_t _diff_current;
    void _send_bm1366(uint8_t header, uint8_t * data, uint8_t len);
    void _set_chip_address(uint8_t address);
    void _set_chain_inactive();
    void _set_version_mask(uint32_t version_mask);
    bool _set_hash_frequency(float target_freq);
public:
    BM1366(HardwareSerial &sport, uint32_t init_baud, uint8_t rx, uint8_t tx, uint8_t rst):BMxxx(sport, init_baud, rx, tx, rst) {
        this->_diff_current = 0;
    }
    void init(uint64_t freq, int diff, uint8_t asic_count) override;
    void change_uart_baud(uint32_t baudrate) override;
    void frequency_ramp_up(float target_frequency) override;
    bool set_frequency(float current_frequency, float target_frequency) override;
    uint32_t set_job_difficulty(int difficulty) override;
    uint8_t get_asic_count() override;
    uint32_t get_asic_difficulty() override;
    void send_work_to_asic(asic_job *job) override;
    uint16_t get_cores() override;
    uint16_t get_small_cores() override;
    esp_err_t wait_for_result(miner_result *result, uint32_t timeout_ms = 60*1000) override;
};
#endif
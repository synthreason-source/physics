#pragma once
#include "../stratum/ecdf_miner.h"   // ecdf_state_t, ecdf_leap — pure math
#include "../stratum/stratum.h"      // pool_job_data_t — full definition needed
#include <esp_err.h>
#include <map>
#include <vector>

// Forward declaration only for AsicMinerClass — defined in miner.h
// (included by ecdf_miner_asic.cpp, not here, to avoid circular deps)
class AsicMinerClass;

// ── Per-difficulty ECDF tier ──────────────────────────────────────────────────
struct ecdf_tier_t {
    ecdf_state_t state    = {};
    uint32_t     diff     = 0;
    uint32_t     last_use = 0;   // logical tick of most recent get(); used for LRU eviction
};

// Max distinct diff tiers kept alive at once. Bounds memory when a pool
// oscillates between many diff values between clean-job resets.
#ifndef ECDF_MAX_TIERS
# define ECDF_MAX_TIERS 8u
#endif

// ── Multi-difficulty manager ──────────────────────────────────────────────────
struct ecdf_multi_t {
    std::map<uint32_t, ecdf_tier_t> tiers;
    uint32_t tick = 0;   // monotonically increasing logical clock for LRU

    ecdf_tier_t& get(uint32_t diff) {
        tick++;
        auto it = tiers.find(diff);
        if (it != tiers.end()) {
            it->second.last_use = tick;
            return it->second;
        }

        if (tiers.size() >= ECDF_MAX_TIERS) {
            // Evict the least-recently-used tier to keep the map bounded.
            auto victim = tiers.begin();
            for (auto cur = tiers.begin(); cur != tiers.end(); ++cur) {
                if (cur->second.last_use < victim->second.last_use)
                    victim = cur;
            }
            tiers.erase(victim);
        }

        ecdf_tier_t t;
        t.diff     = diff;
        t.last_use = tick;
        ecdf_reset(t.state);
        tiers[diff] = t;
        return tiers[diff];
    }

    void reset_all() { tiers.clear(); tick = 0; }
};

// ── Share result ──────────────────────────────────────────────────────────────
struct ecdf_share_t {
    uint32_t nonce;
    uint32_t version;
    uint8_t  asic_id;
    uint8_t  job_id;
};

// ── Leap metadata (optional, for logging / adaptive tuning) ───────────────────
struct ecdf_leap_result_t {
    uint32_t leap_A;        // Exp(1)     predicted offset
    uint32_t leap_B;        // Gamma(2,1) predicted offset
    uint32_t leap_used;     // interpolated leap applied
    float    alpha;         // blend weight (0=A pure, 1=B pure)
    uint32_t start_nonce;   // ASIC starting_nonce set
};

// ── Main ASIC dual-curve leap scan ────────────────────────────────────────────
uint32_t ecdf_scan_window_asic(ecdf_multi_t              &multi,
                               AsicMinerClass            &asic,
                               pool_job_data_t           *pool_job,
                               uint32_t                   nonce_period_ms,
                               std::vector<ecdf_share_t> &out_shares,
                               ecdf_leap_result_t        *out_leap = nullptr);

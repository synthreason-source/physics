#pragma once
#include "../stratum/ecdf_miner.h"   // ecdf_state_t, ecdf_leap — pure math
#include "../stratum/stratum.h"      // pool_job_data_t — full definition needed
#include <esp_err.h>
#include <map>
#include <vector>

// Forward declaration only for AsicMinerClass — defined in miner.h
// (included by ecdf_miner_asic.cpp, not here, to avoid circular deps)
class AsicMinerClass;

// ── Per-difficulty ECDF tier ──────────────────────────────────────────────────
struct ecdf_tier_t {
    ecdf_state_t state = {};
    uint32_t     diff  = 0;
};

// ── Multi-difficulty manager ──────────────────────────────────────────────────
struct ecdf_multi_t {
    std::map<uint32_t, ecdf_tier_t> tiers;

    ecdf_tier_t& get(uint32_t diff) {
        auto it = tiers.find(diff);
        if (it == tiers.end()) {
            ecdf_tier_t t;
            t.diff = diff;
            ecdf_reset(t.state);
            tiers[diff] = t;
            return tiers[diff];
        }
        return it->second;
    }

    void reset_all() { tiers.clear(); }
};

// ── Share result ──────────────────────────────────────────────────────────────
struct ecdf_share_t {
    uint32_t nonce;
    uint32_t version;
    uint8_t  asic_id;
    uint8_t  job_id;
};

// ── Leap metadata (optional, for logging / adaptive tuning) ───────────────────
struct ecdf_leap_result_t {
    uint32_t leap_A;        // Exp(1)     predicted offset
    uint32_t leap_B;        // Gamma(2,1) predicted offset
    uint32_t leap_used;     // interpolated leap applied
    float    alpha;         // blend weight (0=A pure, 1=B pure)
    uint32_t start_nonce;   // ASIC starting_nonce set
};

// ── Main ASIC dual-curve leap scan ────────────────────────────────────────────
uint32_t ecdf_scan_window_asic(ecdf_multi_t              &multi,
                               AsicMinerClass            &asic,
                               pool_job_data_t           *pool_job,
                               uint32_t                   nonce_period_ms,
                               std::vector<ecdf_share_t> &out_shares,
                               ecdf_leap_result_t        *out_leap = nullptr);

#include "ecdf_miner_asic.h"   // pulls in stratum.h + ecdf_miner.h
#include "miner.h"             // AsicMinerClass full definition
#include "../utils/logger/logger.h"
#include <Arduino.h>           // millis()

// ── Internal xorshift32 (static — no symbol clash with ecdf_miner.cpp) ────────
static inline uint32_t _xs32(uint32_t &s) {
    s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s;
}
static inline float _rng_unit(uint32_t &s) {
    return (float)(_xs32(s) >> 1) / (float)(1u << 31);
}

// ── compute_leap_AB ───────────────────────────────────────────────────────────
// Peeks at both Curve-A and Curve-B leap sizes WITHOUT advancing the anchor,
// so the caller can log both values before committing.
// Consumes two RNG draws from s.rng (same sequence as ecdf_leap).
// ─────────────────────────────────────────────────────────────────────────────
static void compute_leap_AB(ecdf_state_t &s,
                            uint32_t &out_A,
                            uint32_t &out_B,
                            float    &out_alpha,
                            uint32_t &out_blended)
{
    float mg = (s.fitted && s.mean_gap > 0.0f) ? s.mean_gap : 1.0f;

    float u1 = _rng_unit(s.rng);
    float u2 = _rng_unit(s.rng);
    if (u1 < 1e-7f) u1 = 1e-7f;
    if (u2 < 1e-7f) u2 = 1e-7f;

    float fA = -mg * logf(1.0f - u1);                          // Curve A
    float fB = -mg * (logf(1.0f - u1) + logf(1.0f - u2));     // Curve B

    float alpha = s.cv;
    if (alpha > 1.0f) alpha = 1.0f;
    if (alpha < 0.0f) alpha = 0.0f;

    float fBlend = (1.0f - alpha) * fA + alpha * fB;

    out_A       = (fA     < 1.0f) ? 1u : (uint32_t)(fA     + 0.5f);
    out_B       = (fB     < 1.0f) ? 1u : (uint32_t)(fB     + 0.5f);
    out_blended = (fBlend < 1.0f) ? 1u : (uint32_t)(fBlend + 0.5f);
    out_alpha   = alpha;
}

// ── ecdf_scan_window_asic ─────────────────────────────────────────────────────
//
// Flow:
//   1. Compute Curve-A (Exp(1)) and Curve-B (Gamma(2,1)) leap offsets.
//   2. Blend by alpha = cv  (0=regular→A, 1=bursty→B).
//   3. Set pool_job->starting_nonce = anchor + blended_leap.
//   4. Open a conf-width window around that landing point.
//   5. Call asic.mining() to send the job to the ASIC chip.
//   6. Listen for results; feed every returned nonce back into the ECDF
//      so future leaps self-refine as more gaps are observed.
//   7. On hit  → update anchor to last hit nonce.
//      On miss → advance anchor past end of scanned window.
// ─────────────────────────────────────────────────────────────────────────────
uint32_t ecdf_scan_window_asic(ecdf_multi_t              &multi,
                               AsicMinerClass            &asic,
                               pool_job_data_t           *pool_job,
                               uint32_t                   nonce_period_ms,
                               std::vector<ecdf_share_t> &out_shares,
                               ecdf_leap_result_t        *out_leap)
{
    out_shares.clear();

    uint32_t      diff = (uint32_t)asic.get_asic_diff();
    ecdf_tier_t  &tier = multi.get(diff);
    ecdf_state_t &s    = tier.state;

    // ── 1. Dual-curve leap ────────────────────────────────────────────────────
    uint32_t leap_A, leap_B, leap_used;
    float    alpha;

    if (s.fitted) {
        compute_leap_AB(s, leap_A, leap_B, alpha, leap_used);
    } else {
        // Bootstrap: use diff-scaled window until ECDF is trained
        leap_A    = (diff > 0) ? diff : 65536u;
        leap_B    = leap_A * 2;
        alpha     = 0.0f;
        leap_used = leap_A;
    }

    // ── 2. Starting nonce = anchor + interpolated leap ────────────────────────
    uint32_t start = s.anchor + leap_used;
    if (start < s.anchor) start = 0xFFFFFFFFu;   // overflow guard

    // ── 3. Conf window around the leap landing point ──────────────────────────
    uint32_t w = s.fitted ? ecdf_window(s, ECDF_DEFAULT_CONF) : leap_used;
    uint32_t end = start + w;
    if (end < start) end = 0xFFFFFFFFu;

    // ── 4. Expose leap metadata to caller ────────────────────────────────────
    if (out_leap) {
        out_leap->leap_A      = leap_A;
        out_leap->leap_B      = leap_B;
        out_leap->leap_used   = leap_used;
        out_leap->alpha       = alpha;
        out_leap->start_nonce = start;
    }

    LOG_D("ecdf[diff=%u]: anchor=0x%08x leapA=%u leapB=%u used=%u "
          "alpha=%.3f start=0x%08x w=%u",
          diff, s.anchor, leap_A, leap_B, leap_used, alpha, start, w);

    // ── 5. Send job to ASIC ───────────────────────────────────────────────────
    pool_job->starting_nonce = start;
    if (!asic.mining(pool_job)) {
        LOG_E("ecdf_scan_window_asic: mining() failed");
        s.anchor += leap_used;
        return leap_used;
    }

    // ── 6. Listen for ASIC results ────────────────────────────────────────────
    const uint32_t MAX_TIMEOUT_MS = 8000u;
    const uint32_t PER_LISTEN_MS  = 200u;

    uint64_t budget_ms = (uint64_t)w * nonce_period_ms;
    if (budget_ms > MAX_TIMEOUT_MS) budget_ms = MAX_TIMEOUT_MS;

    uint32_t deadline       = millis() + (uint32_t)budget_ms;
    uint32_t last_hit_nonce = 0;
    bool     any_hit        = false;

    while ((int32_t)(deadline - millis()) > 0) {
        uint32_t remaining = deadline - millis();
        uint32_t slice     = (remaining < PER_LISTEN_MS) ? remaining : PER_LISTEN_MS;

        miner_result result;
        esp_err_t err = asic.listen_asic_rsp(&result, slice);

        if (err == ESP_ERR_TIMEOUT) continue;
        if (err != ESP_OK) {
            LOG_W("ecdf_scan_window_asic: listen error %d", err);
            continue;
        }

        uint32_t n = result.asic.nonce;

        // Feed hit back into ECDF — gap from leap start teaches future leaps
        if (n > s.anchor) {
            ecdf_add_gap(s, n - s.anchor);
        }

        ecdf_share_t share;
        share.nonce   = n;
        share.version = result.asic.version;
        share.asic_id = result.asic_id;
        share.job_id  = result.asic.job_id;
        out_shares.push_back(share);

        if (!any_hit || n > last_hit_nonce) {
            last_hit_nonce = n;
            any_hit        = true;
        }

        LOG_D("ecdf[diff=%u]: HIT nonce=0x%08x job=%d asic=%d "
              "fitted=%d mean_gap=%.0f cv=%.3f alpha=%.3f",
              diff, n, share.job_id, share.asic_id,
              s.fitted, s.mean_gap, s.cv, alpha);
    }

    // ── 7. Advance anchor ─────────────────────────────────────────────────────
    if (any_hit) {
        s.anchor = last_hit_nonce;
        return last_hit_nonce - (start - 1);
    } else {
        // Miss: skip past scanned region so next leap starts fresh
        s.anchor = end;
        return w;
    }
}
